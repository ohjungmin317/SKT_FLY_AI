## 판다스 참조
- 리스트 
```
doc = [['Joe', 20, 85.10, 'A', 'Swimming'],
        ['Nat', 21, 77.80, 'B', 'Reading'],
        ['Harry', 19, 91.54, 'A', 'Music'],
        ['Sam', 20, 88.78, 'A', 'Painting'],
        ['Monica', 22, 60.55, 'B', 'Dancing']]

c_name = ['Name', 'Age', 'Marks', 'Grade', 'Hobby']
idx = ['s1', 's2', 's3', 's4', 's5']

```
- 딕서너리
```

- 딕셔너리
doc = {'Name' :['Joe','Nat','Harry','Sam','Monica',],
        'Age':[20, 21, 19, 20, 22],
        'Marks':[85.10, 77.80, 91.54, 88.78, 60.55],
        'Grade':['A', 'B', 'A', 'A', 'B',],
        'Hobby':['Swmming', 'Reading', 'Music', 'Painting', 'Dancing']}
```
- merge()함수
```
shop = { 'Shop_id' : ['SP01', 'SP02', 'SP03', 'SP04'],
        'City' : ['Chennai', 'Madurai', 'Trichy', 'Coimbatore'],
        'ZipCode' : [600001, 625001, 620001, 641001] }

product = { 'Shop_id' : ['SP01', 'SP02', 'SP02', 'SP03', 'SP03', 'SP03', 'SP05'],
           'product_id' : ['p01', 'p02', 'p03', 'p01', 'p02', 'p03', 'p02'],
           'price' : [220, 500, 145, 225, 510, 150, 505] }
```

## 데이터 설명
```
- BASE : https://drive.google.com/uc?id=
- Cats_and_Dogs_Filtered.zip : https://drive.google.com/uc?id=1u6OARnMhuLq--AmmklBLJrX9J_sw_bts
- HumanActivity Recognition : https://drive.google.com/uc?id=1ypa5iZ1dLDO-zGRO_yDXrJnMvjRGUG4v

```
